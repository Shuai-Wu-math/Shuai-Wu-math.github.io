function [ dy, y ] = lpm( n, x )
%lpm Computes all Legendre polynomials up to degree n and their derivatives at given points.
%
%   [dy, y] = LPM(n, x) calculates the values of Legendre polynomials of degrees
%   0 to n and their derivatives at the point(s) x. Legendre polynomials are
%   commonly used in mathematical physics and numerical analysis.
%
%   Inputs:
%       n  - Non-negative integer, the highest degree of Legendre polynomials to compute.
%       x  - Scalar or vector, the point(s) at which to evaluate the polynomials.
%
%   Outputs:
%       y  - Matrix of Legendre polynomial values, where y(:,k+1) contains the
%            kth-degree polynomial evaluated at x (k = 0 to n). Size is [size(x), n+1].
%       dy - Matrix of derivatives of Legendre polynomials, where dy(:,k+1) contains
%            the derivative of the kth-degree polynomial at x (k = 0 to n).
%            Size is [size(x), n+1].
%
%   Example:
%       [dy, y] = lpm(3, 0.5); % Compute Legendre polynomials of degrees 0 to 3
%                               % and their derivatives at x = 0.5
%
%   See also: lp

    lx = length( x );
    if n == 0, dy = zeros( lx, 1 ); y = ones( lx, 1 ); return; end
    if n == 1, dy = [ zeros( lx, 1 ) ones( lx, 1 ) ]; y = [ ones( lx, 1 ) x ]; return; end
    
    y1 = ones( lx, 1 ); y2 = x; y = [ y1 y2 ];
    dy1 = zeros( lx, 1); dy2 = ones( lx, 1 ); dy = [ dy1 dy2 ];
    for i = 1 : n - 1
        y = [ y ( ( 2 * i + 1 ) * x .* y2 - i * y1) / ( i + 1 )  ];
        dy = [ dy ( 2 * i +1 ) * y2 + dy1 ];
        y1 = y2; y2 = y( : , end ); dy1 = dy2; dy2 = dy( : , end );
    end
    
end