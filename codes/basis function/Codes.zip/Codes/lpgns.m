function [ x, w ] = lpgns( n )
%lpgns Computes Gauss-Legendre quadrature nodes and weights for n points.
%
%   [x, w] = lpgns(n) calculates the n Gauss-Legendre quadrature nodes and their
%   corresponding weights for numerical integration over the interval [-1, 1].
%   Gauss-Legendre quadrature is widely used for approximating definite integrals.
%
%   Inputs:
%       n  - Positive integer, the number of quadrature nodes.
%
%   Outputs:
%       x  - Vector of length n, containing the Gauss-Legendre quadrature nodes in [-1, 1].
%       w  - Vector of length n, containing the corresponding quadrature weights.
%
%   Example:
%       [x, w] = lpgns(5); % Compute 5 Gauss-Legendre quadrature nodes and weights

arr_n = 1 : n; arr_n = arr_n';
the = ( 4 * arr_n -1 ) / ( 4 * n + 2 ) * pi;
x1 = - ( 1 - ( n - 1 ) / ( 8 * n^3 ) - ( 39 - 28 ./ sin( the ).^2 ) / ( 384 *n^4 ) ).* cos( the );
eps = 1e-15;
x0 = x1 + eps + 1;

while max( abs( x1 - x0 ) ) > eps
   x0 = x1; 
   [ dy, y ] = lp( n, x1 );
   x1 = x1 - y ./ dy;
end
x = x1;

w = 2 ./ ( ( 1 - x.^2 ) .*  dy.^2 );

end

