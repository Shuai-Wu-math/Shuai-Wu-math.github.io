function [ dy, y ] = lp( n, x )
%lp Computes the nth Legendre polynomial and its derivative at a given point.
%
%   [dy, y] = lp(n, x) calculates the value of the nth Legendre polynomial
%   and its derivative at the point(s) x. Legendre polynomials are widely
%   used in mathematical physics and numerical analysis.
%
%   Inputs:
%       n  - Non-negative integer, the degree of the Legendre polynomial.
%       x  - Scalar or vector, the point(s) at which to evaluate the polynomial.
%
%   Outputs:
%       y  - Value of the nth Legendre polynomial at point x, matching the size of x.
%       dy - Derivative of the nth Legendre polynomial at point x, matching the size of x.
%
%   Example:
%       [dy, y] = lp(3, 0.5); % Compute the 3rd-degree Legendre polynomial
%                              % and its derivative at x = 0.5

    lx = length( x );
    if n == 0, dy = zeros( lx, 1 ); y = ones( lx, 1 ); return; end 
    if n == 1, dy = ones( lx, 1 ); y = x; return; end
    
    y1 = ones( lx, 1 ); y2 = x; 
    dy1 = zeros( lx, 1); dy2 = ones( lx, 1 );
    for i = 1 : n - 1
        y = ( ( 2 * i + 1 ) * x .* y2 - i * y1 ) / ( i + 1 );
        dy = ( 2 * i + 1 ) * y2 + dy1;
        y1 = y2; y2 = y; dy1 = dy2; dy2 = dy;
    end
    
end